<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/login.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в админ панель</title>
</head>
<body>
    <div class="container">
    <h1>Вход в админ панель</h1><br>
    <form action="admin.php">
    <input type="text" placeholder="Login" name="login"><br> <br>
    <input type="text" placeholder="Password" name="password"><br><br>
    <button type="submit">Войти</button>
</form>
    
    </div>
</body>
</html>